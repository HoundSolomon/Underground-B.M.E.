
Underground B.M.E. - Production Package (One-Click Build)
========================================================

Quick Start
-----------
1. Unzip the package.
2. Install Python 3.8+.
3. Install FFmpeg and ensure 'ffmpeg' is in your system PATH:
   - https://ffmpeg.org/download.html
4. Open a terminal/command prompt in the project folder.
5. Install Python dependencies:
   pip install -r requirements.txt
6. Run the build script (one command):
   python build.py
7. Open index.html in your browser to preview the site. The store will auto-list tracks, generate previews, embed covers, and update manifest.json.

Notes
-----
- Prices are locked: tracks $0.99, subscription $9.99/month.
- Auto-generated covers use a graffiti/abstract style and include a $0.99 tag.
- New tracks dropped into /tracks/ will be auto-processed by build.py.
