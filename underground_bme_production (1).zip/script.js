
fetch('manifest.json').then(r=>r.json()).then(data=>{
  const grid = document.getElementById('grid');
  data.forEach(t=>{
    const tile = document.createElement('div'); tile.className='tile';
    tile.innerHTML = `<img src="${t.cover}" class="cover"/><div class="meta"><div class="title">${t.title}</div><div class="artist">${t.artist}</div><div class="album">${t.album}</div><div class="info">Length: ${t.length} • Bitrate: ${t.bitrate}</div><div class="controls"><button class="play" data-src="${t.preview}">▶</button><div class="progress"><div class="bar"></div></div><button class="buy" data-file="${t.file}">Buy for $0.99</button></div></div>`;
    grid.appendChild(tile);
  });
  let currentAudio=null;
  document.addEventListener('click', e=>{
    if(e.target.classList.contains('play')){
      const btn=e.target; const src=btn.dataset.src;
      if(currentAudio && !currentAudio.paused){ currentAudio.pause(); document.querySelectorAll('.play').forEach(b=>b.textContent='▶'); }
      if(!currentAudio || currentAudio.src.indexOf(src)===-1){ currentAudio = new Audio(src); currentAudio.play(); btn.textContent='⏸'; const progress = btn.parentElement.querySelector('.bar'); currentAudio.ontimeupdate = ()=>{ const pct=(currentAudio.currentTime/currentAudio.duration)*100; if(!isNaN(pct)) progress.style.width = pct + '%'; }; currentAudio.onended = ()=>{ btn.textContent='▶'; progress.style.width='0%'; }; } else { if(currentAudio.paused){ currentAudio.play(); btn.textContent='⏸'; } else { currentAudio.pause(); btn.textContent='▶'; } }
    } else if(e.target.classList.contains('buy')){
      const file=e.target.dataset.file; const a=document.createElement('a'); a.href=file; a.download=file.split('/').pop(); document.body.appendChild(a); a.click(); a.remove();
    }
  });
});
