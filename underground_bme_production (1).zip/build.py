#!/usr/bin/env python3
import json, subprocess, sys, os
from pathlib import Path
from mutagen.id3 import ID3, APIC, TIT2, TPE1, TALB, TDRC, TCON, COMM
from mutagen.mp3 import MP3
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).parent
TRACKS = ROOT / "tracks"
COVERS = ROOT / "covers"
PREVIEWS = ROOT / "preview"
CONFIG = ROOT / "config" / "metadata.json"
MANIFEST = ROOT / "manifest.json"

# load metadata config
if CONFIG.exists():
    with open(CONFIG, "r") as f:
        metadata = json.load(f)
else:
    metadata = {}

def auto_generate_cover(trackname, outpath):
    W=H=1200
    base = Image.new("RGB",(W,H),(10,10,10))
    draw = ImageDraw.Draw(base)
    for i in range(0,W,12):
        draw.rectangle([i,0,i+12,H], fill=(10+(i%60),20+(i%40),30+(i%50)))
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",72)
    except:
        font = ImageFont.load_default()
    title = Path(trackname).stem.replace("_"," ").upper()
    w,h = draw.textsize(title, font=font)
    draw.text(((W-w)/2, H*0.4), title, font=font, fill=(220,255,200))
    draw.rectangle((W-220,30,W-40,110), fill=(10,10,10))
    draw.text((W-200,40), "$0.99", font=font, fill=(180,255,170))
    base.save(outpath, optimize=True, quality=85)

def embed_cover_and_metadata(trackfile, meta):
    audio = MP3(trackfile)
    try:
        tags = ID3(trackfile)
    except Exception:
        tags = ID3()
    cover_path = Path(meta.get("cover", ""))
    if not cover_path.exists():
        cover_path = COVERS / (Path(trackfile).stem + ".png")
        auto_generate_cover(trackfile, cover_path)
        meta["cover"] = f"covers/{cover_path.name}"
    with open(cover_path, "rb") as imgf:
        img_data = imgf.read()
    tags.delall("APIC")
    tags.add(APIC(encoding=3, mime="image/png", type=3, desc="Cover", data=img_data))
    tags.delall("TIT2"); tags.add(TIT2(encoding=3, text=meta.get("title", Path(trackfile).stem)))
    tags.delall("TPE1"); tags.add(TPE1(encoding=3, text=meta.get("artist","Underground B.M.E.")))
    tags.delall("TALB"); tags.add(TALB(encoding=3, text=meta.get("album","Underground B.M.E. Vault")))
    tags.delall("TDRC"); tags.add(TDRC(encoding=3, text=meta.get("year","2025")))
    tags.delall("TCON"); tags.add(TCON(encoding=3, text=meta.get("genre","Underground Hip-Hop")))
    tags.delall("COMM"); tags.add(COMM(encoding=3, lang='eng', desc='Comment', text='Distributed by Underground B.M.E. — Underground Salute'))
    tags.save(trackfile)

def generate_preview(trackfile, outpath, duration=30):
    cmd = ["ffmpeg", "-y", "-i", str(trackfile), "-ss", "0", "-t", str(duration), "-acodec", "libmp3lame", "-ab", "128k", str(outpath)]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def update_manifest():
    manifest = []
    for f in TRACKS.iterdir():
        if f.suffix.lower() != ".mp3": continue
        try:
            audio = MP3(f)
            length = int(audio.info.length); mins=length//60; secs=length%60; duration=f"{mins}:{secs:02d}"
            bitrate = int(getattr(audio.info,"bitrate",0)/1000) if getattr(audio.info,"bitrate",0) else "Unknown"
        except:
            duration="Unknown"; bitrate="Unknown"
        key = f.name
        meta = metadata.get(key, {})
        cover = meta.get("cover", f"covers/{f.stem}.png")
        preview = PREVIEWS / (f.stem + "_preview.mp3")
        if not preview.exists():
            generate_preview(f, preview)
        manifest.append({
            "file": f"tracks/{f.name}",
            "preview": f"preview/{preview.name}",
            "title": meta.get("title", f.stem),
            "artist": meta.get("artist", "Underground B.M.E."),
            "album": meta.get("album", "Underground B.M.E. Vault"),
            "cover": cover,
            "length": duration,
            "bitrate": f"{bitrate}kbps" if bitrate!="Unknown" else "Unknown",
            "price": "$0.99"
        })
    with open(MANIFEST, "w") as mf:
        json.dump(manifest, mf, indent=2)
    print("Manifest updated.", len(manifest), "tracks listed.")

def main():
    PREVIEWS.mkdir(exist_ok=True)
    for f in TRACKS.iterdir():
        if f.suffix.lower() != ".mp3": continue
        key = f.name
        meta = metadata.get(key, {})
        cover_path = Path(meta.get("cover",""))
        if not cover_path or not Path(cover_path).exists():
            auto_cover = COVERS / (f.stem + ".png")
            auto_generate_cover(f.name, auto_cover)
            meta["cover"] = f"covers/{auto_cover.name}"
            metadata[key] = meta
        print("Embedding metadata into", f.name)
        embed_cover_and_metadata(str(f), meta)
        prev_out = PREVIEWS / (f.stem + "_preview.mp3")
        print("Generating preview for", f.name)
        generate_preview(str(f), prev_out)
    with open(CONFIG, "w") as cf:
        json.dump(metadata, cf, indent=2)
    update_manifest()
    print("Build complete.")

if __name__=='__main__':
    main()
